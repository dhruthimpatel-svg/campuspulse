// Obsidian Pulse reminder: Routing keeps the landing stage separate from the product shell while every product page has a clear escape route.
import { Toaster } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import ErrorBoundary from '@/components/ErrorBoundary'
import { ThemeProvider } from '@/contexts/ThemeContext'
import { Route, Switch } from 'wouter'
import Home from '@/pages/Home'
import Dashboard from '@/pages/Dashboard'
import Events from '@/pages/Events'
import EventDetail from '@/pages/EventDetail'
import Clubs from '@/pages/Clubs'
import Workshops from '@/pages/Workshops'
import MapPage from '@/pages/MapPage'
import Resources from '@/pages/Resources'
import Departments from '@/pages/Departments'
import Announcements from '@/pages/Announcements'
import Profile from '@/pages/Profile'
import Settings from '@/pages/Settings'
import Admin from '@/pages/Admin'
import Auth from '@/pages/Auth'
import RlsCheck from '@/pages/RlsCheck'
import NotFound from '@/pages/NotFound'
import { AppShell } from '@/components/AppShell'
import { CampusAssistant } from '@/components/CampusAssistant'

function ProductRoutes() {
  return <AppShell><Switch><Route path="/dashboard" component={Dashboard} /><Route path="/events/:id" component={EventDetail} /><Route path="/events" component={Events} /><Route path="/clubs" component={Clubs} /><Route path="/workshops" component={Workshops} /><Route path="/map" component={MapPage} /><Route path="/resources" component={Resources} /><Route path="/departments" component={Departments} /><Route path="/announcements" component={Announcements} /><Route path="/profile" component={Profile} /><Route path="/settings" component={Settings} /><Route path="/admin" component={Admin} /><Route path="/auth" component={Auth} /><Route path="/rls-check" component={RlsCheck} /><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch><CampusAssistant /></AppShell>
}
function Router() {
  // make sure to consider if you need authentication for certain routes
  return <Switch><Route path="/" component={Home} /><Route><ProductRoutes /></Route></Switch>
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark" switchable><TooltipProvider><Toaster position="bottom-left" /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>
}
