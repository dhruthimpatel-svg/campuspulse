// Obsidian Pulse reminder: The shell is a split-orbit frame—identity rail on desktop, compact command header on mobile.
import { Bell, BookOpen, ChevronRight, CircleUserRound, Command, LayoutDashboard, Map, Menu, Search, Settings2, Sparkles, UsersRound, X, Wrench, CalendarDays, Megaphone } from 'lucide-react'
import { useState } from 'react'
import { Link, useLocation } from 'wouter'
import { BNMIT, notifications } from '@/data/mockData'
import { LogoMark } from './Shared'

const navItems = [
  { href: '/dashboard', label: 'Home', icon: LayoutDashboard },
  { href: '/events', label: 'Events', icon: CalendarDays },
  { href: '/clubs', label: 'Clubs', icon: UsersRound },
  { href: '/workshops', label: 'Workshops', icon: Wrench },
  { href: '/map', label: 'Campus map', icon: Map },
  { href: '/resources', label: 'Resources', icon: Command },
  { href: '/departments', label: 'Departments', icon: BookOpen },
  { href: '/announcements', label: 'Updates', icon: Megaphone },
  { href: '/dashboard#ask-campus', label: 'Ask Campus', icon: Sparkles },
]

export function AppShell({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation()
  const [menuOpen, setMenuOpen] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const unreadCount = notifications.filter((item) => item.unread).length

  return (
    <div className="page-shell min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[236px] border-r border-white/8 bg-[#0d0e0c]/75 px-5 py-6 backdrop-blur-2xl lg:flex lg:flex-col">
        <Link href="/" className="mb-12 px-2"><LogoMark /></Link>
        <div className="px-2"><p className="eyebrow">{BNMIT.shortName} / student companion</p><p className="mt-2 text-xs leading-5 text-muted-foreground">{BNMIT.name}</p></div>
        <nav className="mt-4 space-y-1" aria-label="Primary navigation">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = location === href || (href === '/dashboard' && location === '/')
            return <Link key={href} href={href} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${active ? 'bg-white/[0.09] text-foreground' : 'text-muted-foreground hover:bg-white/[0.05] hover:text-foreground'}`}><Icon size={16} strokeWidth={active ? 2 : 1.6} className={active ? 'text-[#c8f169]' : ''} /><span>{label}</span>{active && <span className="ml-auto size-1.5 rounded-full bg-[#c8f169] shadow-[0_0_10px_#c8f169]" />}</Link>
          })}
        </nav>
        <div className="mt-auto space-y-3">
          <Link href="/settings" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted-foreground transition hover:bg-white/[0.05] hover:text-foreground"><Settings2 size={16} />Settings</Link>
          <div className="liquid-glass rounded-2xl p-4">
            <div className="flex items-center gap-3"><div className="grid size-8 place-items-center rounded-full bg-white/[0.08] text-xs font-semibold text-[#c8f169]"><CircleUserRound size={15} /></div><div className="min-w-0"><p className="truncate text-xs font-medium">Student identity</p><p className="truncate text-[0.65rem] text-muted-foreground">Not connected</p></div></div>
            <div className="mt-4 border-t border-white/8 pt-3"><p className="font-mono text-[0.58rem] uppercase tracking-[0.1em] text-muted-foreground">Official address</p><p className="mt-2 text-[0.65rem] leading-5 text-muted-foreground">{BNMIT.address}</p></div>
          </div>
        </div>
      </aside>

      <div className="lg:pl-[236px]">
        <header className="sticky top-0 z-30 border-b border-white/8 bg-[#0d0e0c]/82 px-4 py-3 backdrop-blur-xl sm:px-6 lg:px-10">
          <div className="flex items-center justify-between gap-4">
            <Link href="/" className="lg:hidden"><LogoMark /></Link>
            <div className="hidden items-center gap-2 text-xs text-muted-foreground lg:flex"><span className="signal-pip size-1.5" />BNMIT campus companion <span className="mx-1 text-white/20">/</span><span className="font-mono text-[0.65rem]">OFFICIAL LINKS + SYNC STATUS</span></div>
            <div className="ml-auto flex items-center gap-2">
              <button onClick={() => navigate('/events')} className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-muted-foreground transition hover:border-white/20 hover:text-foreground md:flex"><Search size={14} /><span>Search campus</span><kbd className="ml-5 rounded border border-white/10 px-1.5 py-0.5 font-mono text-[0.55rem]">⌘ K</kbd></button>
              <button aria-label="Open notifications" onClick={() => setNotificationsOpen((value) => !value)} className="relative grid size-9 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-muted-foreground transition hover:border-white/20 hover:text-foreground"><Bell size={16} />{unreadCount > 0 && <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-[#c8f169] shadow-[0_0_8px_#c8f169]" />}</button>
              <Link aria-label="Open profile" href="/profile" className="grid size-9 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-muted-foreground transition hover:border-white/20 hover:text-foreground"><CircleUserRound size={17} /></Link>
              <button aria-label="Open menu" onClick={() => setMenuOpen((value) => !value)} className="grid size-9 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-muted-foreground lg:hidden">{menuOpen ? <X size={17} /> : <Menu size={17} />}</button>
            </div>
          </div>
          {menuOpen && <nav className="mt-4 grid gap-1 border-t border-white/8 pt-3 lg:hidden">{navItems.map(({ href, label, icon: Icon }) => <Link onClick={() => setMenuOpen(false)} key={href} href={href} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-muted-foreground hover:bg-white/[0.05] hover:text-foreground"><Icon size={16} />{label}<ChevronRight className="ml-auto" size={15} /></Link>)}</nav>}
        </header>

        {notificationsOpen && <div className="fixed right-4 top-[4.75rem] z-50 w-[min(370px,calc(100vw-2rem))] liquid-glass rounded-2xl p-5 shadow-2xl sm:right-6 lg:right-10"><div className="flex items-start justify-between"><div><p className="eyebrow">Inbox</p><h3 className="mt-2 text-lg font-medium">Notifications</h3></div><button aria-label="Close notifications" onClick={() => setNotificationsOpen(false)} className="text-muted-foreground hover:text-foreground"><X size={17} /></button></div><div className="mt-5 space-y-1">{notifications.map((item) => <div key={item.id} className={`rounded-xl p-3 ${item.unread ? 'bg-white/[0.07]' : ''}`}><div className="flex gap-3"><span className={`mt-1.5 size-1.5 shrink-0 rounded-full ${item.unread ? 'bg-[#c8f169]' : 'bg-white/20'}`} /><div><p className="text-sm font-medium">{item.title}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{item.description}</p><p className="mt-2 font-mono text-[0.6rem] uppercase tracking-[0.12em] text-muted-foreground">{item.timestamp}</p></div></div></div>)}</div><Link href="/announcements" onClick={() => setNotificationsOpen(false)} className="mt-4 flex items-center justify-center gap-2 border-t border-white/8 pt-4 text-xs text-[#c8f169]">See all updates <ChevronRight size={14} /></Link></div>}
        <main className="px-4 py-8 sm:px-6 lg:px-10 lg:py-10">{children}</main>
      </div>
    </div>
  )
}
