// Obsidian Pulse reminder: The assistant opens from a compact live signal and behaves like a calm campus instrument panel.
import { ArrowUp, Bot, ChevronDown, Sparkles, X } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { askCampusAssistant } from '@/services/aiService'
import { toast } from 'sonner'

type Message = { id: number; role: 'assistant' | 'user'; text: string }
const suggestions = ['Where is BNMIT located?', 'What clubs are available?', 'What events are coming up?', 'What departments does BNMIT have?']

export function CampusAssistant() {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [messages, setMessages] = useState<Message[]>([{ id: 1, role: 'assistant', text: 'Hi — I’m the CampusPulse BNMIT demo assistant. Ask me about verified links, clubs, departments, and the campus location.' }])
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }) }, [messages, loading])

  async function submit(question: string) {
    const trimmed = question.trim()
    if (!trimmed || loading) return
    setInput('')
    setMessages((current) => [...current, { id: Date.now(), role: 'user', text: trimmed }])
    setLoading(true)
    const response = await askCampusAssistant(trimmed)
    setLoading(false)
    setMessages((current) => [...current, { id: Date.now() + 1, role: 'assistant', text: response }])
  }

  return <>
    {open && <div className="fixed bottom-24 right-4 z-50 w-[min(390px,calc(100vw-2rem))] origin-bottom-right animate-[slide-up_.22s_cubic-bezier(.23,1,.32,1)] liquid-glass rounded-2xl p-4 shadow-2xl sm:right-7"><div className="flex items-center justify-between border-b border-white/10 pb-4"><div className="flex items-center gap-3"><div className="grid size-9 place-items-center rounded-xl bg-[#c8f169] text-[#0d0e0c]"><Bot size={18} /></div><div><div className="flex items-center gap-2"><p className="text-sm font-medium">Ask Campus · BNMIT</p><span className="signal-pip size-1.5 pulse-live" /></div><p className="mt-0.5 text-[0.68rem] text-muted-foreground">Demo layer · official-source aware</p></div></div><button aria-label="Close assistant" onClick={() => setOpen(false)} className="text-muted-foreground transition hover:text-foreground"><X size={17} /></button></div><div ref={scrollRef} className="mt-4 max-h-[290px] space-y-3 overflow-y-auto pr-1">{messages.map((message) => <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[86%] rounded-2xl px-3.5 py-2.5 text-xs leading-5 ${message.role === 'user' ? 'rounded-br-md bg-[#c8f169] text-[#0d0e0c]' : 'rounded-bl-md bg-white/[0.08] text-foreground/85'}`}>{message.text}</div></div>)}{loading && <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="signal-pip size-1.5 pulse-live" />Checking the BNMIT knowledge layer<span className="ml-1 inline-flex gap-0.5"><i className="size-1 rounded-full bg-white/50 animate-bounce" /><i className="size-1 rounded-full bg-white/50 animate-bounce [animation-delay:100ms]" /><i className="size-1 rounded-full bg-white/50 animate-bounce [animation-delay:200ms]" /></span></div>}</div><div className="mt-4 flex gap-2 overflow-x-auto pb-1">{suggestions.slice(0, 2).map((suggestion) => <button key={suggestion} onClick={() => submit(suggestion)} className="shrink-0 rounded-full border border-white/10 px-3 py-1.5 text-[0.65rem] text-muted-foreground transition hover:border-[#c8f169]/50 hover:text-[#c8f169]">{suggestion}</button>)}</div><form onSubmit={(event) => { event.preventDefault(); submit(input) }} className="mt-3 flex items-center gap-2 rounded-xl border border-white/10 bg-black/20 p-1.5"><input aria-label="Ask Campus assistant" value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask about BNMIT..." className="min-w-0 flex-1 bg-transparent px-2 text-xs outline-none placeholder:text-muted-foreground" /><button type="submit" aria-label="Send question" disabled={!input.trim() || loading} className="grid size-8 shrink-0 place-items-center rounded-lg bg-[#c8f169] text-[#0d0e0c] transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-40"><ArrowUp size={15} /></button></form></div>}
    <button aria-label={open ? 'Close Campus assistant' : 'Open Campus assistant'} onClick={() => setOpen((value) => !value)} className="fixed bottom-5 right-4 z-50 flex items-center gap-3 rounded-full border border-[#c8f169]/25 bg-[#c8f169] px-4 py-3 text-xs font-semibold text-[#0d0e0c] shadow-[0_10px_40px_rgba(200,241,105,0.18)] transition hover:-translate-y-0.5 hover:bg-white active:scale-[0.97] sm:bottom-7 sm:right-7"><span className="grid size-7 place-items-center rounded-full bg-[#0d0e0c] text-[#c8f169]"><Sparkles size={14} /></span><span>{open ? 'Close assistant' : 'Ask campus'}</span>{open ? <ChevronDown size={15} /> : <span className="signal-pip size-1.5 bg-[#0d0e0c] shadow-none" />}</button>
  </>
}
