// BNMIT map contract: only verified institution coordinates are mapped; Google embed is optional and OpenStreetMap remains the safe fallback.
import { ExternalLink, MapPin } from 'lucide-react'
import { BNMIT } from '@/data/mockData'

const configuredGoogleEmbedUrl = (import.meta.env.VITE_GOOGLE_MAPS_EMBED_URL as string | undefined)?.trim()

export function MapCanvas() {
  const { lat, lon } = BNMIT.coordinates
  const bbox = `${lon - 0.012}%2C${lat - 0.009}%2C${lon + 0.012}%2C${lat + 0.009}`
  const openStreetMapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat}%2C${lon}`
  const mapUrl = configuredGoogleEmbedUrl || openStreetMapUrl
  const googleUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(BNMIT.mapQuery)}`
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(BNMIT.mapQuery)}`
  return <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#121410]"><div className="relative h-[460px] sm:h-[560px]"><iframe title="BNMIT location map" src={mapUrl} className="size-full border-0 grayscale-[.35] contrast-[.9]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" /><div className="pointer-events-none absolute left-4 top-4 flex items-center gap-3 rounded-xl border border-white/15 bg-[#0d0e0c]/85 px-3 py-2 backdrop-blur-md"><span className="grid size-7 place-items-center rounded-lg bg-[#c8f169] text-[#0d0e0c]"><MapPin size={15} /></span><div><p className="text-xs font-medium">BNMIT</p><p className="font-mono text-[0.58rem] uppercase tracking-[0.1em] text-white/50">Verified place marker</p></div></div><div className="absolute bottom-4 left-4 right-4 flex flex-wrap gap-2"><a href={googleUrl} target="_blank" rel="noreferrer" className="pointer-events-auto inline-flex items-center gap-2 rounded-lg bg-[#c8f169] px-3 py-2 text-xs font-medium text-[#0d0e0c] transition hover:bg-white">Open in Google Maps <ExternalLink size={13} /></a><a href={directionsUrl} target="_blank" rel="noreferrer" className="pointer-events-auto inline-flex items-center gap-2 rounded-lg border border-white/20 bg-[#0d0e0c]/80 px-3 py-2 text-xs text-white backdrop-blur-md transition hover:border-white/50">Get directions <ExternalLink size={13} /></a></div></div><div className="border-t border-white/10 px-5 py-4"><p className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-muted-foreground">{configuredGoogleEmbedUrl ? 'Google Maps Embed' : 'OpenStreetMap'} · {BNMIT.coordinates.source}</p></div></div>
}
