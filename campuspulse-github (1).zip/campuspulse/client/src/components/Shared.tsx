// Obsidian Pulse reminder: Shared primitives keep the tactile glass language, metadata rhythm, and active Pulse Lime signal consistent.
import { CalendarDays, Check, Clock3, MapPin, Sparkles, Users, Zap } from 'lucide-react'
import { Link } from 'wouter'
import type { CampusEvent, Resource, ResourceStatus } from '@/data/mockData'

const statusStyles: Record<ResourceStatus, string> = {
  Available: 'bg-[#c8f169]/12 text-[#c8f169] border-[#c8f169]/25',
  Busy: 'bg-[#f1c76a]/12 text-[#f1c76a] border-[#f1c76a]/25',
  Maintenance: 'bg-[#ff8f9c]/12 text-[#ffb4bd] border-[#ff8f9c]/25',
  Unavailable: 'bg-white/[0.06] text-muted-foreground border-white/10',
}

export function LogoMark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5" aria-label="CampusPulse">
      <span className="relative grid size-8 place-items-center rounded-full border border-white/20 bg-black/25 text-[#c8f169] shadow-[0_0_28px_rgba(200,241,105,0.12)]">
        <span className="absolute size-4 rounded-full border border-[#c8f169] border-r-transparent rotate-45" />
        <span className="absolute size-4 rounded-full border border-white/60 border-l-transparent -rotate-45" />
        <span className="size-1.5 rounded-full bg-[#c8f169] shadow-[0_0_10px_#c8f169]" />
      </span>
      {!compact && <span className="text-[1.05rem] font-semibold tracking-[-0.04em]">CampusPulse</span>}
    </span>
  )
}

export function SignalLabel({ children }: { children: React.ReactNode }) {
  return <span className="signal-line eyebrow">{children}</span>
}

export function SectionHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <SignalLabel>{eyebrow}</SignalLabel>
        <h2 className="mt-3 text-balance text-3xl font-light tracking-[-0.05em] text-foreground sm:text-[2.6rem]">{title}</h2>
        {description && <p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  )
}

export function StatusBadge({ status }: { status: ResourceStatus }) {
  return (
    <span className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 font-mono text-[0.63rem] uppercase tracking-[0.12em] ${statusStyles[status]}`}>
      <span className={`size-1.5 rounded-full ${status === 'Available' ? 'bg-[#c8f169] pulse-live' : status === 'Busy' ? 'bg-[#f1c76a]' : 'bg-[#ff8f9c]'}`} />
      {status}
    </span>
  )
}

export function MetricCard({ label, value, detail, accent, icon }: { label: string; value: string; detail: string; accent: string; icon: string }) {
  const Icon = icon === 'calendar' ? CalendarDays : icon === 'sparkles' ? Sparkles : icon === 'door' ? Zap : Users
  return (
    <article className="liquid-glass reveal rounded-2xl p-5" style={{ animationDelay: `${['Events today', 'Workshops', 'Available rooms', 'Announcements'].indexOf(label) * 70}ms` }}>
      <div className="flex items-start justify-between gap-4">
        <span className="grid size-9 place-items-center rounded-xl border border-white/10 bg-white/[0.05]" style={{ color: accent }}><Icon size={17} strokeWidth={1.6} /></span>
        <span className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-muted-foreground">Live</span>
      </div>
      <div className="mt-8 flex items-end justify-between gap-4">
        <div>
          <div className="text-4xl font-light tracking-[-0.07em]" style={{ color: accent }}>{value}</div>
          <div className="mt-1 text-sm text-foreground">{label}</div>
        </div>
        <p className="max-w-[8rem] text-right text-xs leading-5 text-muted-foreground">{detail}</p>
      </div>
    </article>
  )
}

export function EventCard({ event, onRegister, registered = false }: { event: CampusEvent; onRegister?: (event: CampusEvent) => void; registered?: boolean }) {
  return (
    <article className="group overflow-hidden rounded-2xl border border-white/10 bg-white/[0.035] transition duration-300 hover:-translate-y-1 hover:border-white/25 hover:bg-white/[0.06]">
      <Link href={`/events/${event.id}`} className="block">
        <div className="relative aspect-[1.55] overflow-hidden bg-white/5">
          <img src={event.image} alt="" className="size-full object-cover opacity-80 transition duration-700 group-hover:scale-105 group-hover:opacity-100" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d0e0c]/85 via-transparent to-transparent" />
          <div className="absolute left-4 top-4 flex items-center gap-2">
            <span className="rounded-full border border-white/15 bg-black/35 px-2.5 py-1 font-mono text-[0.6rem] uppercase tracking-[0.12em] text-white/80 backdrop-blur-md">{event.category}</span>
          </div>
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between gap-4">
            <p className="font-mono text-[0.63rem] uppercase tracking-[0.1em] text-white/65">{event.dateLabel}</p>
            <span className="flex items-center gap-1.5 font-mono text-[0.63rem] text-[#c8f169]"><span className="signal-pip size-1.5" />{event.seats} seats</span>
          </div>
        </div>
      </Link>
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Link href={`/events/${event.id}`} className="text-lg font-medium tracking-[-0.035em] transition hover:text-[#c8f169]">{event.title}</Link>
            <p className="mt-1 text-xs text-muted-foreground">Hosted by {event.organizer}</p>
          </div>
          <span className="mt-1 size-2 rounded-full" style={{ background: event.accent, boxShadow: `0 0 12px ${event.accent}` }} />
        </div>
        <div className="mt-5 grid grid-cols-2 gap-y-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-2"><Clock3 size={13} />{event.time.split('–')[0]}</span>
          <span className="flex items-center gap-2"><MapPin size={13} />{event.location}</span>
        </div>
        <button onClick={() => onRegister?.(event)} className={`mt-5 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition active:scale-[0.98] ${registered ? 'bg-[#c8f169]/15 text-[#c8f169]' : 'bg-white text-[#0d0e0c] hover:bg-[#c8f169]'}`}>
          {registered ? <><Check size={15} /> In your pulse</> : <>Join the signal <span className="ml-auto text-base transition-transform group-hover:translate-x-0.5">↗</span></>}
        </button>
      </div>
    </article>
  )
}

export function ResourceCard({ resource, onClick }: { resource: Resource; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="liquid-glass w-full rounded-2xl p-5 text-left transition duration-300 hover:-translate-y-0.5 hover:border-white/25">
      <div className="flex items-start justify-between gap-3">
        <div><p className="text-sm font-medium">{resource.name}</p><p className="mt-1 text-xs text-muted-foreground">{resource.type}</p></div>
        <StatusBadge status={resource.status} />
      </div>
      <div className="mt-7 flex items-end justify-between"><span className="text-sm text-foreground/80">{resource.detail}</span><span className="font-mono text-[0.62rem] text-muted-foreground">{resource.capacity}</span></div>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/8"><div className="h-full rounded-full transition-all" style={{ width: resource.status === 'Available' ? '72%' : resource.status === 'Busy' ? '44%' : '16%', background: resource.status === 'Maintenance' ? '#ff8f9c' : '#c8f169' }} /></div>
    </button>
  )
}

export function EmptyState({ title, description }: { title: string; description: string }) {
  return <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-14 text-center"><Sparkles className="mx-auto text-muted-foreground" size={24} /><h3 className="mt-4 font-medium">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">{description}</p></div>
}
