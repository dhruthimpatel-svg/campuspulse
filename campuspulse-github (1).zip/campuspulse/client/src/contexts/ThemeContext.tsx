// Obsidian Pulse reminder: Theme changes are smooth, explicit, and keep the Pulse Lime signal legible in both modes.
import { createContext, useContext, useEffect, useMemo, useState } from 'react'

type Theme = 'dark' | 'light'
type ThemeContextValue = { theme: Theme; toggleTheme: () => void; setTheme: (theme: Theme) => void }
const ThemeContext = createContext<ThemeContextValue>({ theme: 'dark', toggleTheme: () => undefined, setTheme: () => undefined })

export function ThemeProvider({ children, defaultTheme = 'dark' }: { children: React.ReactNode; defaultTheme?: Theme; switchable?: boolean }) {
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('campuspulse-theme') as Theme | null) ?? defaultTheme)
  useEffect(() => { document.documentElement.classList.remove('dark', 'light'); document.documentElement.classList.add(theme); document.body.classList.remove('dark', 'light'); document.body.classList.add(theme); localStorage.setItem('campuspulse-theme', theme) }, [theme])
  const value = useMemo(() => ({ theme, setTheme, toggleTheme: () => setTheme((current) => current === 'dark' ? 'light' : 'dark') }), [theme])
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
}
export const useTheme = () => useContext(ThemeContext)
