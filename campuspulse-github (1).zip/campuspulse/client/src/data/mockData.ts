// BNMIT data contract: official links and supplied institutional facts are separated from demo-only data.
export const BNMIT = {
  name: 'B. N. M. Institute of Technology',
  shortName: 'BNMIT',
  address: 'Post Box No. 7087, 12th Main Road, 27th Cross, Banashankari II Stage, Bangalore – 560070',
  website: 'https://www.bnmit.org/',
  mapQuery: 'B. N. M. Institute of Technology, 12th Main Road, 27th Cross, Banashankari II Stage, Bengaluru 560070',
  coordinates: { lat: 12.921883, lon: 77.5675933, source: 'OpenStreetMap Nominatim geocoder' },
  phone: '+91-80-26711781',
  email: 'principal@bnmit.in',
} as const

export type EventCategory = 'Technical' | 'Cultural' | 'Sports' | 'Workshop' | 'Competition' | 'Club Event'
export type EventStatus = 'official' | 'demo'
export type Priority = 'Important' | 'General' | 'Event' | 'Academic'
export type ResourceStatus = 'Available' | 'Busy' | 'Maintenance' | 'Unavailable'

export interface CampusEvent {
  id: string
  title: string
  category: EventCategory
  dateLabel: string
  dateISO?: string
  time: string
  location: string
  organizer: string
  seats?: number
  capacity?: number
  description: string
  image: string
  accent: string
  tags: string[]
  status: EventStatus
  registrationLink?: string
}

export interface Club {
  members?: number
  upcomingEvent?: string
  id: string
  name: string
  category: string
  description: string
  facultyCoordinator: string
  studentCoordinator: string
  officialUrl: string
  socialUrl?: string
  initials: string
  accent: string
}

export interface Department { id: string; name: string; level: 'UG' | 'PG' | 'Foundation'; officialUrl: string }
export interface Resource { id: string; name: string; type: string; status: ResourceStatus; detail: string; officialUrl?: string; capacity?: string }
export interface CampusLocation { id: string; name: string; officialUrl: string; description: string; x?: number; y?: number; status?: ResourceStatus; hours?: string; availability?: string; activity?: string }
export interface Announcement { id: string; title: string; description: string; date: string; priority: Priority; unread: boolean; officialUrl?: string }
export interface Notification { id: string; title: string; description: string; timestamp: string; type: 'Official' | 'System'; unread: boolean }

const unavailable = 'Information unavailable in the current official sync.'
const officialClubsUrl = 'https://www.bnmit.org/clubs/'

export const clubs: Club[] = [
  'Nature Club', 'Tech-IT', 'Nexus Community', 'MUN', 'Evocative Voices', 'Kala Bhageerathi', 'RPA', 'Under25xBNMIT', 'Q-Quotient', 'Bloom', 'Siggraph', 'TEDx BNMIT', 'Animatrix', 'Adventure Club', 'RoboHawks', 'HashVault'
].map((name) => ({ id: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'), name, category: 'BNMIT student club', description: unavailable, facultyCoordinator: unavailable, studentCoordinator: unavailable, officialUrl: name === 'Nature Club' ? 'https://www.bnmit.org/nature-club/' : name === 'Kala Bhageerathi' ? 'https://www.bnmit.org/students-life/cultural-kala-bhageerathi/' : name === 'Adventure Club' ? 'https://www.bnmit.org/home/adventure-club/' : officialClubsUrl, initials: name.split(/\s+/).map((part) => part[0]).join('').slice(0, 3), accent: '#C8F169' }))

export const departments: Department[] = [
  ['Artificial Intelligence & Machine Learning', 'UG', 'https://www.bnmit.org/artificial-intelligence-machine-learning/'],
  ['Computer Science & Engineering', 'UG', 'https://www.bnmit.org/computer-science-engineering/'],
  ['Electronics & Communication Engineering', 'UG', 'https://www.bnmit.org/electronics-communication-engineering/'],
  ['Electrical & Electronics Engineering', 'UG', 'https://www.bnmit.org/electrical-electronics-engineering/'],
  ['Information Science & Engineering', 'UG', 'https://www.bnmit.org/information-science-engineering/'],
  ['Mechanical Engineering', 'UG', 'https://www.bnmit.org/mechanical-engineering/'],
  ['Business Administration', 'PG', 'https://www.bnmit.org/mba/'],
  ['Mathematics', 'Foundation', 'https://www.bnmit.org/department-of-mathematics/'],
  ['Physics', 'Foundation', 'https://www.bnmit.org/department-of-physics/'],
  ['Chemistry', 'Foundation', 'https://www.bnmit.org/department-of-chemistry/'],
  ['Humanities', 'Foundation', 'https://www.bnmit.org/department-of-humanities/'],
].map(([name, level, officialUrl], index) => ({ id: `department-${index + 1}`, name, level: level as Department['level'], officialUrl }))

export interface Workshop { id: string; title: string; instructor: string; level: 'Beginner' | 'Intermediate' | 'Advanced'; duration: string; date: string; seats: number; category: string }
export const workshops: Workshop[] = []

export const officialEvents: CampusEvent[] = []
export const sampleEvents: CampusEvent[] = [
  { id: 'demo-event-1', title: 'Sample event — replace from official feed', category: 'Technical', dateLabel: 'Date unavailable', time: 'Time unavailable', location: 'Venue unavailable', organizer: 'Official BNMIT Events', description: 'This is a clearly labelled demo card used to validate the experience before an official BNMIT event feed is connected.', image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=85', accent: '#C8F169', tags: ['Demo only', 'API-ready'], status: 'demo' },
  { id: 'demo-event-2', title: 'Sample workshop — replace from official feed', category: 'Workshop', dateLabel: 'Date unavailable', time: 'Time unavailable', location: 'Venue unavailable', organizer: 'Official BNMIT Events', description: 'Connect the BNMIT calendar or a campus events service to replace this placeholder with verified event data.', image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=85', accent: '#C8F169', tags: ['Demo only', 'API-ready'], status: 'demo' },
]
// Compatibility alias for existing components; product pages now distinguish officialEvents from sampleEvents.
export const events = sampleEvents

export const resources: Resource[] = [
  { id: 'library', name: 'Library and Information Center', type: 'Student resource', status: 'Unavailable', detail: unavailable, officialUrl: 'https://www.bnmit.org/library-information-centre/' },
  { id: 'campus-tour', name: 'Campus Tour', type: 'Campus facility', status: 'Unavailable', detail: unavailable, officialUrl: 'https://www.bnmit.org/campus-tour/' },
  { id: 'main-block', name: 'Main Block', type: 'Infrastructure', status: 'Unavailable', detail: unavailable, officialUrl: 'https://www.bnmit.org/about-us/main-block/' },
  { id: 'new-block', name: 'New Block', type: 'Infrastructure', status: 'Unavailable', detail: unavailable, officialUrl: 'https://www.bnmit.org/about-us/new-block/' },
  { id: 'auditorium', name: 'Auditorium Block', type: 'Infrastructure', status: 'Unavailable', detail: unavailable, officialUrl: 'https://www.bnmit.org/about-us/auditorium-block/' },
  { id: 's-block', name: 'S Block', type: 'Infrastructure', status: 'Unavailable', detail: unavailable, officialUrl: 'https://www.bnmit.org/about-us/s-block/' },
]

export const campusLocations: CampusLocation[] = [
  { id: 'bnmit-campus', name: BNMIT.name, officialUrl: BNMIT.website, description: BNMIT.address },
]
// Legacy map collection is now intentionally empty: internal POI coordinates are not verified.
export const locations = campusLocations.map((location) => ({ ...location, x: 50, y: 50, status: 'Unavailable' as ResourceStatus, hours: unavailable, availability: unavailable, activity: unavailable }))

export const announcements: Announcement[] = []
export const notifications: Notification[] = [{ id: 'sync-notice', title: 'Official BNMIT sync is not connected', description: 'Events, notices, and live capacity will appear here when an official source is connected.', timestamp: 'Current status', type: 'System', unread: true }]

export const activityData: Array<{ time: string; activity: number | null }> = []
export const metricCards = [
  { label: 'Upcoming events', value: officialEvents.length.toString().padStart(2, '0'), detail: officialEvents.length ? 'From official BNMIT sources' : 'No official events synced', accent: '#C8F169', icon: 'calendar' },
  { label: 'Active clubs', value: clubs.length.toString().padStart(2, '0'), detail: 'Listed on BNMIT Student Life', accent: '#C8F169', icon: 'sparkles' },
  { label: 'Campus updates', value: announcements.length.toString().padStart(2, '0'), detail: announcements.length ? 'Official notices synced' : 'No official notices synced', accent: '#C8F169', icon: 'bell' },
  { label: 'Student resources', value: resources.length.toString().padStart(2, '0'), detail: 'Official links available', accent: '#C8F169', icon: 'door' },
] as const

export const aiResponses: Record<string, string> = {
  default: `I’m the CampusPulse BNMIT demo assistant. I can point you to verified BNMIT links and tell you when information is unavailable.`,
  location: `${BNMIT.name} is at ${BNMIT.address}. The map uses the BNMIT place resolved through OpenStreetMap.`,
  clubs: `BNMIT’s official Student Life and Clubs pages list communities including Nature Club, Tech-IT, Nexus Community, MUN, Kala Bhageerathi, TEDx BNMIT, RoboHawks, and HashVault. Individual details are shown only when verified.`,
  events: 'No official BNMIT events have been synced yet. Connect the official calendar or events API to populate this answer.',
  departments: 'BNMIT’s official site lists AIML, CSE, ECE, EEE, ISE, Mechanical Engineering, Business Administration, Mathematics, Physics, Chemistry, and Humanities.',
  library: 'The official BNMIT Library and Information Center page is available from Resources. Opening hours and live availability are unavailable in the current sync.',
}
