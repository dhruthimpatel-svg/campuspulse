import { useEffect, useState } from 'react'
import type { LiveDataState, LiveResult } from '@/services/supabaseDataService'

export function useLiveCollection<T>(loader: () => Promise<LiveResult<T[]>>) {
  const [data, setData] = useState<T[]>([])
  const [state, setState] = useState<LiveDataState>('unconfigured')
  const [error, setError] = useState<string>()

  useEffect(() => {
    let active = true
    setState('unconfigured')
    loader().then((result) => {
      if (!active) return
      setData(result.data)
      setState(result.state)
      setError(result.error)
    }).catch((caught: unknown) => {
      if (!active) return
      setData([])
      setState('error')
      setError(caught instanceof Error ? caught.message : 'Unable to reach Supabase.')
    })
    return () => { active = false }
  }, [loader])

  return { data, state, error, isLoading: state === 'unconfigured' && !error }
}
