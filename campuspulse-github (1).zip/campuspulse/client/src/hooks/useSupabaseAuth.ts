import { useEffect, useState } from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'

export type SupabaseRole = 'student' | 'admin'

export function useSupabaseAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [role, setRole] = useState<SupabaseRole | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let mounted = true
    async function loadSession() {
      const { data, error: sessionError } = await supabase.auth.getSession()
      if (!mounted) return
      if (sessionError) setError(sessionError.message)
      setUser(data.session?.user ?? null)
      if (data.session?.user) {
        const profile = await supabase.from('profiles').select('role').eq('id', data.session.user.id).maybeSingle()
        if (mounted) {
          if (profile.error) setError(profile.error.message)
          setRole((profile.data?.role as SupabaseRole | null) ?? 'student')
        }
      }
      if (mounted) setLoading(false)
    }
    void loadSession()
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null)
      if (!session?.user) setRole(null)
      void loadSession()
    })
    return () => { mounted = false; listener.subscription.unsubscribe() }
  }, [])

  async function signIn(email: string, password: string) {
    setError(null)
    const result = await supabase.auth.signInWithPassword({ email, password })
    if (result.error) setError(result.error.message)
    return result
  }

  async function signUp(email: string, password: string) {
    setError(null)
    const result = await supabase.auth.signUp({ email, password })
    if (result.error) setError(result.error.message)
    return result
  }

  async function signOut() {
    const result = await supabase.auth.signOut()
    if (result.error) setError(result.error.message)
  }

  return { user, role, loading, error, isAuthenticated: Boolean(user), isAdmin: role === 'admin', signIn, signUp, signOut }
}
