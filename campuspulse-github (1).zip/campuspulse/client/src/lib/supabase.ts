import { createClient } from '@supabase/supabase-js'

const rawSupabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseUrl = rawSupabaseUrl?.replace(/\/rest\/v1\/?$/, '').replace(/\/$/, '')
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase credentials missing. CampusPulse will remain in demo mode.')
}

export const supabaseProjectEndpoint = supabaseUrl || 'https://placeholder.supabase.co'

export const supabase = createClient(
  supabaseProjectEndpoint,
  supabaseAnonKey || 'placeholder'
)
