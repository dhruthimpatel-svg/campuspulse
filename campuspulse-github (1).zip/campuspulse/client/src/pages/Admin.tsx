import { useAuth } from '@/_core/hooks/useAuth'
import { useState } from 'react'
import { ShieldCheck, Plus, Save, Trash2 } from 'lucide-react'
import { Link } from 'wouter'
import { toast } from 'sonner'
import { createAnnouncement, createEvent } from '@/services/supabaseDataService'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { SignalLabel } from '@/components/Shared'

const ADMIN_WRITES_ENABLED = true
const eventCategories = ['Technical', 'Cultural', 'Sports', 'Workshop', 'Competition', 'Club Event'] as const

type EventCategory = (typeof eventCategories)[number]

export default function Admin() {
  const { user: manusUser } = useAuth()
  const { user, role, loading, error: authError } = useSupabaseAuth()
  const [title, setTitle] = useState('')
  const [category, setCategory] = useState<EventCategory>('Technical')
  const [dateISO, setDateISO] = useState('')
  const [time, setTime] = useState('')
  const [location, setLocation] = useState('')
  const [organizer, setOrganizer] = useState('')
  const [description, setDescription] = useState('')
  const [eventPublished, setEventPublished] = useState(false)
  const [announcementTitle, setAnnouncementTitle] = useState('')
  const [announcementDescription, setAnnouncementDescription] = useState('')
  const [announcementPublished, setAnnouncementPublished] = useState(false)
  const [saving, setSaving] = useState(false)

  if (loading) return <div className="mx-auto max-w-[1000px] py-20 text-sm text-muted-foreground">Checking secure admin access…</div>
  if (!user || role !== 'admin') return <div className="mx-auto max-w-[1000px]"><SignalLabel>Admin / Access</SignalLabel><h1 className="mt-5 text-5xl font-light tracking-[-0.065em]">Admin access required.</h1><p className="mt-5 max-w-xl text-sm leading-7 text-muted-foreground">This route is protected by Supabase Auth and database RLS. A signed-in student or visitor cannot write to CampusPulse.</p>{authError && <p className="mt-4 text-xs text-[#ff9b8a]">{authError}</p>}<div className="mt-8 flex flex-wrap gap-3"><Link href="/auth" className="rounded-xl bg-white px-4 py-3 text-xs font-medium text-[#0d0e0c]">Sign in with Supabase</Link><Link href="/dashboard" className="rounded-xl border border-white/10 px-4 py-3 text-xs text-muted-foreground">Return to campus</Link></div></div>

  async function saveEvent() {
    if (!ADMIN_WRITES_ENABLED) return toast('Admin writes are currently disabled.')
    if (!title.trim() || !dateISO || !time.trim() || !location.trim() || !organizer.trim() || !description.trim()) return toast.error('Complete every event field before publishing')
    setSaving(true)
    const { error } = await createEvent({ title: title.trim(), dateISO, category, organizer: organizer.trim(), location: location.trim(), time: time.trim(), description: description.trim(), tags: [], isPublished: eventPublished })
    setSaving(false)
    if (error) return toast.error(error.message)
    setTitle('')
    setCategory('Technical')
    setDateISO('')
    setTime('')
    setLocation('')
    setOrganizer('')
    setDescription('')
    setEventPublished(false)
    toast.success(eventPublished ? 'Event published to Supabase' : 'Event saved as an unpublished draft')
  }

  async function saveAnnouncement() {
    if (!ADMIN_WRITES_ENABLED) return toast('Admin writes are currently disabled.')
    if (!announcementTitle.trim() || !announcementDescription.trim()) return toast.error('Complete the announcement title and description first')
    setSaving(true)
    const { error } = await createAnnouncement({ title: announcementTitle.trim(), description: announcementDescription.trim(), priority: 'General', isPublished: announcementPublished })
    setSaving(false)
    if (error) return toast.error(error.message)
    setAnnouncementTitle('')
    setAnnouncementDescription('')
    setAnnouncementPublished(false)
    toast.success(announcementPublished ? 'Announcement published to Supabase' : 'Announcement saved as an unpublished draft')
  }

  return <div className="mx-auto max-w-[1100px]"><SignalLabel>Admin / BNMIT content desk</SignalLabel><div className="mt-5 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><h1 className="text-5xl font-light tracking-[-0.065em]">Keep the pulse current.</h1><p className="mt-4 max-w-xl text-sm leading-7 text-muted-foreground">Signed in with Supabase Auth as {user.email ?? manusUser?.email ?? 'an authorized admin'}.</p></div><div className="flex items-center gap-2 rounded-full border border-[#c8f169]/20 bg-[#c8f169]/[0.06] px-3 py-2 text-xs text-[#c8f169]"><ShieldCheck size={15} /> {role} session</div></div><div className="mt-12 grid gap-4 lg:grid-cols-2"><form onSubmit={(event) => { event.preventDefault(); void saveEvent() }} className="liquid-glass rounded-2xl p-6"><h2 className="text-xl font-medium">Add event</h2><p className="mt-2 text-sm text-muted-foreground">Use verified BNMIT details only. Supabase RLS authorizes the final write.</p><div className="mt-6 space-y-3"><input required value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Event title" className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><select value={category} onChange={(event) => setCategory(event.target.value as EventCategory)} className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none">{eventCategories.map((item) => <option key={item} value={item}>{item}</option>)}</select><input required type="datetime-local" value={dateISO} onChange={(event) => setDateISO(event.target.value)} className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><input required value={time} onChange={(event) => setTime(event.target.value)} placeholder="Displayed time (for example, 10:00 AM)" className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><input required value={location} onChange={(event) => setLocation(event.target.value)} placeholder="Verified venue" className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><input required value={organizer} onChange={(event) => setOrganizer(event.target.value)} placeholder="Verified organizer" className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><textarea required value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Verified event description" rows={4} className="w-full resize-none rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><label className="flex items-center gap-3 text-xs text-muted-foreground"><input type="checkbox" checked={eventPublished} onChange={(event) => setEventPublished(event.target.checked)} className="accent-[#c8f169]" /> Publish immediately to students</label></div><button disabled={saving} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-3 text-xs font-medium text-[#0d0e0c] disabled:cursor-wait disabled:opacity-60"><Plus size={15} /> {saving ? 'Saving event…' : 'Add event'}</button></form><form onSubmit={(event) => { event.preventDefault(); void saveAnnouncement() }} className="liquid-glass rounded-2xl p-6"><h2 className="text-xl font-medium">Add announcement</h2><p className="mt-2 text-sm text-muted-foreground">Only verified admin sessions can publish through Supabase RLS.</p><div className="mt-6 space-y-3"><input required value={announcementTitle} onChange={(event) => setAnnouncementTitle(event.target.value)} placeholder="Announcement title" className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><textarea required value={announcementDescription} onChange={(event) => setAnnouncementDescription(event.target.value)} placeholder="Verified announcement description" rows={4} className="w-full resize-none rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none" /><label className="flex items-center gap-3 text-xs text-muted-foreground"><input type="checkbox" checked={announcementPublished} onChange={(event) => setAnnouncementPublished(event.target.checked)} className="accent-[#c8f169]" /> Publish immediately to students</label></div><button disabled={saving} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-3 text-xs font-medium text-[#0d0e0c] disabled:cursor-wait disabled:opacity-60"><Save size={15} /> {saving ? 'Saving announcement…' : 'Add announcement'}</button></form></div><div className="mt-10 rounded-2xl border border-dashed border-white/15 p-6 text-sm text-muted-foreground"><div className="flex items-center gap-2 text-foreground"><Trash2 size={16} /> RLS gate active</div><p className="mt-3 max-w-2xl leading-6">The database policies, not this page, decide whether a write is allowed. The admin write flag is enabled after controlled student-denial and admin-allow RLS tests passed. The database remains the final authorization boundary.</p></div></div>
}
