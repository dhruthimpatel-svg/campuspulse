import { FormEvent, useEffect, useState } from 'react'
import { Link, useLocation } from 'wouter'
import { ArrowLeft, KeyRound, LogIn, UserPlus } from 'lucide-react'
import { toast } from 'sonner'
import { SignalLabel } from '@/components/Shared'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { supabase } from '@/lib/supabase'

type AuthMode = 'signin' | 'signup' | 'forgot' | 'reset'

export default function Auth() {
  const [, navigate] = useLocation()
  const { user, loading, error, signIn, signUp, signOut } = useSupabaseAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState<AuthMode>('signin')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    const { data: listener } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') setMode('reset')
    })
    return () => listener.subscription.unsubscribe()
  }, [])

  if (loading) return <div className="mx-auto max-w-[620px] py-20 text-sm text-muted-foreground">Checking secure session…</div>
  if (user && mode !== 'reset') return <div className="mx-auto max-w-[620px]"><SignalLabel>Supabase Auth / Session</SignalLabel><h1 className="mt-5 text-5xl font-light tracking-[-0.065em]">You’re signed in.</h1><p className="mt-5 text-sm leading-7 text-muted-foreground">{user.email}. Continue to the admin route if your profile has the explicit admin role.</p><div className="mt-8 flex flex-wrap gap-3"><Link href="/admin" className="rounded-xl bg-white px-4 py-3 text-xs font-medium text-[#0d0e0c]">Open admin</Link><button onClick={() => void signOut()} className="rounded-xl border border-white/10 px-4 py-3 text-xs text-muted-foreground">Sign out</button><button onClick={() => void resetLocalSession()} disabled={busy} className="rounded-xl border border-[#ff9b8a]/25 px-4 py-3 text-xs text-[#ffb0a2] disabled:opacity-50">Reset this login</button></div></div>

  async function resetLocalSession() {
    setBusy(true)
    const result = await supabase.auth.signOut({ scope: 'local' })
    for (const storage of [window.localStorage, window.sessionStorage]) {
      for (const key of Object.keys(storage)) {
        if (key.startsWith('sb-') || key.toLowerCase().includes('supabase')) storage.removeItem(key)
      }
    }
    window.history.replaceState({}, document.title, '/auth')
    setEmail('')
    setPassword('')
    setMode('signin')
    setBusy(false)
    if (result.error) return toast.error(result.error.message)
    toast.success('All local login details cleared')
  }

  async function submit(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    if (mode === 'forgot') {
      const result = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/auth` })
      setBusy(false)
      if (result.error) return toast.error(result.error.message)
      toast.success('Password reset email requested')
      setMode('signin')
      return
    }
    if (mode === 'reset') {
      const result = await supabase.auth.updateUser({ password })
      setBusy(false)
      if (result.error) return toast.error(result.error.message)
      toast.success('Password updated securely')
      setMode('signin')
      return
    }
    const result = mode === 'signin' ? await signIn(email, password) : await signUp(email, password)
    setBusy(false)
    if (result.error) return toast.error(result.error.message)
    toast.success(mode === 'signin' ? 'Signed in securely' : 'Account created — check email if confirmation is enabled')
    navigate('/admin')
  }

  const isForgot = mode === 'forgot'
  const isReset = mode === 'reset'
  const title = isForgot ? 'Recover your campus identity.' : isReset ? 'Set a new password.' : 'Connect your campus identity.'
  const eyebrow = isForgot ? 'Supabase Auth / Password recovery' : isReset ? 'Supabase Auth / Set password' : `Supabase Auth / ${mode === 'signin' ? 'Sign in' : 'Create account'}`
  return <div className="mx-auto max-w-[620px]"><SignalLabel>{eyebrow}</SignalLabel><h1 className="mt-5 text-5xl font-light tracking-[-0.065em]">{title}</h1><p className="mt-5 text-sm leading-7 text-muted-foreground">{isForgot ? 'Enter your email and Supabase will send a secure reset link if an account exists.' : isReset ? 'Choose a new password for your CampusPulse account.' : 'Use email/password authentication. Supabase manages the session; RLS decides which records the session can write.'}</p><form onSubmit={submit} className="liquid-glass mt-10 rounded-2xl p-6"><div className="space-y-3"><input autoComplete="off" required type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Email address" className={`w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none ${isReset ? 'hidden' : ''}`} /><input autoComplete={isReset ? 'new-password' : 'current-password'} required minLength={6} type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder={isReset ? 'New password' : 'Password'} className={`w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none ${isForgot ? 'hidden' : ''}`} /></div>{error && <p className="mt-4 text-xs text-[#ff9b8a]">{error}</p>}<button disabled={busy} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-3 text-xs font-medium text-[#0d0e0c] hover:bg-[#c8f169]">{isForgot ? <KeyRound size={15} /> : isReset ? <KeyRound size={15} /> : mode === 'signin' ? <LogIn size={15} /> : <UserPlus size={15} />}{busy ? 'Working…' : isForgot ? 'Send reset link' : isReset ? 'Update password' : mode === 'signin' ? 'Sign in' : 'Create account'}</button>{!isReset && <>{!isForgot && <button type="button" onClick={() => setMode((current) => current === 'signin' ? 'signup' : 'signin')} className="ml-4 text-xs text-muted-foreground hover:text-[#c8f169]">{mode === 'signin' ? 'Create an account' : 'Already have an account? Sign in'}</button>}{mode === 'signin' && <button type="button" onClick={() => setMode('forgot')} className="mt-5 flex items-center gap-2 text-xs text-muted-foreground hover:text-[#c8f169]"><KeyRound size={13} /> Forgot password?</button>}{isForgot && <button type="button" onClick={() => setMode('signin')} className="mt-5 flex items-center gap-2 text-xs text-muted-foreground hover:text-[#c8f169]"><ArrowLeft size={13} /> Back to sign in</button>}</>}<button type="button" onClick={() => void resetLocalSession()} disabled={busy} className="mt-5 block text-xs text-muted-foreground underline decoration-white/20 underline-offset-4 hover:text-[#c8f169] disabled:opacity-50">Clear saved login details</button></form><p className="mt-6 text-xs text-muted-foreground">Need admin access? Create/sign in first, then an authorized operator must promote your Supabase Auth UUID in `public.profiles` after RLS tests pass. Resetting the login clears only this browser’s Supabase session; it does not delete the account or change its role.</p></div>
}
