import { useState } from 'react'
import { Link } from 'wouter'
import { CheckCircle2, LockKeyhole, ShieldCheck, XCircle } from 'lucide-react'
import { SignalLabel } from '@/components/Shared'
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth'
import { supabase, supabaseProjectEndpoint } from '@/lib/supabase'

type CheckState = 'idle' | 'running' | 'passed' | 'failed'
type TestResult = { label: string; state: CheckState; detail: string }

const initialResults: TestResult[] = [
  { label: 'Events insert / update / delete', state: 'idle', detail: 'Not run' },
  { label: 'Announcements insert / update / delete', state: 'idle', detail: 'Not run' },
]

export default function RlsCheck() {
  const { user, role, loading } = useSupabaseAuth()
  const projectEndpoint = supabaseProjectEndpoint
  const projectRef = (() => { try { return new URL(projectEndpoint).hostname.split('.')[0] } catch { return 'unknown' } })()
  const [results, setResults] = useState(initialResults)
  const [running, setRunning] = useState(false)
  const [roleProbe, setRoleProbe] = useState<CheckState>('idle')
  const [roleProbeDetail, setRoleProbeDetail] = useState('Not run')

  if (loading) return <div className="mx-auto max-w-[900px] py-20 text-sm text-muted-foreground">Checking secure session…</div>
  if (!user) return <div className="mx-auto max-w-[900px]"><SignalLabel>Security / RLS test</SignalLabel><h1 className="mt-5 text-5xl font-light tracking-[-0.065em]">Sign in to test RLS.</h1><p className="mt-5 max-w-xl text-sm leading-7 text-muted-foreground">Use a Supabase Auth session before running the controlled permission checks.</p><Link href="/auth" className="mt-8 inline-flex rounded-xl bg-white px-4 py-3 text-xs font-medium text-[#0d0e0c]">Sign in with Supabase</Link></div>

  async function runTest() {
    setRunning(true)
    setRoleProbe('running')
    setRoleProbeDetail('Checking public.is_admin() through this authenticated session…')
    setResults(initialResults.map((item) => ({ ...item, state: 'running', detail: 'Checking…' })))
    const roleResult = await supabase.rpc('is_admin')
    if (roleResult.error || roleResult.data !== true) {
      setRoleProbe('failed')
      setRoleProbeDetail(roleResult.error?.message ?? `Database returned ${String(roleResult.data)} instead of true`)
      setResults(initialResults.map((item) => ({ ...item, state: 'failed', detail: 'Stopped because public.is_admin() did not return true' })))
      setRunning(false)
      return
    }
    setRoleProbe('passed')
    setRoleProbeDetail('Database returned true for this authenticated admin session')
    const next = [...initialResults]
    next[0] = await exerciseTable('events', 0)
    next[1] = await exerciseTable('announcements', 1)
    setResults(next)
    setRunning(false)
  }

  async function exerciseTable(table: 'events' | 'announcements', index: number): Promise<TestResult> {
    const title = table === 'events' ? '[RLS TEST] transient event' : '[RLS TEST] transient announcement'
    const base: Record<string, unknown> = table === 'events'
      ? { title, category: 'Technical', status: 'demo', is_published: false, description: 'Temporary security test record; should be deleted immediately.', tags: [] }
      : { title, description: 'Temporary security test record; should be deleted immediately.', priority: 'General', unread: false, is_published: false }
    const insert = await supabase.from(table).insert(base).select('id').single()
    if (insert.error) {
      const denied = role !== 'admin' && (insert.error.code === '42501' || insert.error.message.toLowerCase().includes('row-level security') || insert.error.message.toLowerCase().includes('permission'))
      return { ...initialResults[index], state: denied ? 'passed' : 'failed', detail: denied ? 'Denied by RLS as expected' : insert.error.message }
    }
    const id = insert.data.id as string
    const update = await supabase.from(table).update({ title: `${title} / updated` }).eq('id', id)
    if (update.error) {
      await supabase.from(table).delete().eq('id', id)
      return { ...initialResults[index], state: 'failed', detail: `Insert allowed, update failed: ${update.error.message}` }
    }
    const remove = await supabase.from(table).delete().eq('id', id)
    if (remove.error) return { ...initialResults[index], state: 'failed', detail: `Write allowed but cleanup failed: ${remove.error.message}` }
    return { ...initialResults[index], state: role === 'admin' ? 'passed' : 'failed', detail: role === 'admin' ? 'Admin RLS allow path passed; test row cleaned up' : 'Unexpected write allowed for non-admin' }
  }

  const allPassed = roleProbe === 'passed' && results.every((result) => result.state === 'passed')
  return <div className="mx-auto max-w-[900px]"><SignalLabel>Security / RLS test</SignalLabel><h1 className="mt-5 text-5xl font-light tracking-[-0.065em]">Verify the database gate.</h1><p className="mt-5 max-w-2xl text-sm leading-7 text-muted-foreground">Run a controlled insert, update, and delete against events and announcements using the current Supabase Auth session. Admin test rows are unpublished and removed immediately.</p><div className="mt-8 flex flex-wrap items-center gap-3"><div className="inline-flex items-center gap-2 rounded-full border border-[#c8f169]/20 bg-[#c8f169]/[0.06] px-3 py-2 text-xs text-[#c8f169]"><ShieldCheck size={14} /> {role ?? 'unknown'} session</div><div className="text-xs text-muted-foreground">{user.email}</div></div><div className="mt-10 grid gap-4 md:grid-cols-4"><div className="liquid-glass rounded-2xl p-5"><div className="flex items-center justify-between gap-4"><h2 className="text-sm font-medium">Supabase project</h2><CheckCircle2 size={18} className="text-[#c8f169]" /></div><p className="mt-3 break-all text-xs leading-6 text-muted-foreground">App endpoint: {projectEndpoint}</p><p className="mt-1 text-xs text-[#c8f169]">Project ref: {projectRef}</p></div><div className="liquid-glass rounded-2xl p-5"><div className="flex items-center justify-between gap-4"><h2 className="text-sm font-medium">Database role helper</h2>{roleProbe === 'passed' ? <CheckCircle2 size={18} className="text-[#c8f169]" /> : roleProbe === 'failed' ? <XCircle size={18} className="text-[#ff9b8a]" /> : <LockKeyhole size={18} className="text-muted-foreground" />}</div><p className="mt-3 text-xs leading-6 text-muted-foreground">{roleProbeDetail}</p></div>{results.map((result) => <div key={result.label} className="liquid-glass rounded-2xl p-5"><div className="flex items-center justify-between gap-4"><h2 className="text-sm font-medium">{result.label}</h2>{result.state === 'passed' ? <CheckCircle2 size={18} className="text-[#c8f169]" /> : result.state === 'failed' ? <XCircle size={18} className="text-[#ff9b8a]" /> : <LockKeyhole size={18} className="text-muted-foreground" />}</div><p className="mt-3 text-xs leading-6 text-muted-foreground">{result.detail}</p></div>)}</div><button disabled={running} onClick={() => void runTest()} className="mt-8 rounded-xl bg-white px-4 py-3 text-xs font-medium text-[#0d0e0c] disabled:cursor-wait disabled:opacity-60">{running ? 'Running RLS checks…' : 'Run controlled RLS checks'}</button>{allPassed && <div className="mt-6 rounded-xl border border-[#c8f169]/20 bg-[#c8f169]/[0.06] p-4 text-xs leading-6 text-[#c8f169]">Both table paths passed for this session. Protected admin writes are enabled; Supabase RLS remains the final authorization boundary.</div>}<p className="mt-6 text-xs leading-6 text-muted-foreground">This page is a verification aid. It never uses the service-role/secret key and never changes a production record intentionally; any admin test rows are unpublished and cleaned up immediately.</p></div>
}
