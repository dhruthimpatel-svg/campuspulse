// BNMIT assistant contract: this transparent demo layer can be replaced with a real AI endpoint without changing the UI.
import { aiResponses } from '@/data/mockData'

export async function askCampusAssistant(question: string): Promise<string> {
  const normalized = question.toLowerCase()
  let response = aiResponses.default
  if (normalized.includes('where') || normalized.includes('locat') || normalized.includes('address') || normalized.includes('map')) response = aiResponses.location
  else if (normalized.includes('department') || normalized.includes('branch') || normalized.includes('course')) response = aiResponses.departments
  else if (normalized.includes('club') || normalized.includes('societ') || normalized.includes('join')) response = aiResponses.clubs
  else if (normalized.includes('event') || normalized.includes('today') || normalized.includes('tomorrow')) response = aiResponses.events
  else if (normalized.includes('library') || normalized.includes('resource') || normalized.includes('facility') || normalized.includes('room')) response = aiResponses.library
  await new Promise((resolve) => window.setTimeout(resolve, 650))
  return response
}
