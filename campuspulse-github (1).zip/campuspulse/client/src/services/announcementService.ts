// Obsidian Pulse reminder: Keep announcement retrieval independent from presentation components.
import { announcements, notifications, type Announcement, type Notification } from '@/data/mockData'

export async function getAnnouncements(): Promise<Announcement[]> {
  return Promise.resolve(announcements)
}

export async function getNotifications(): Promise<Notification[]> {
  return Promise.resolve(notifications)
}
