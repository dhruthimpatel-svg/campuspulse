// BNMIT event contract: official and demo records remain separate so the UI never implies sample data is real.
import { officialEvents, sampleEvents, type CampusEvent } from '@/data/mockData'
import { getLiveEvents } from './supabaseDataService'

export async function getOfficialEvents(): Promise<CampusEvent[]> {
  const result = await getLiveEvents()
  return result.state === 'live' ? result.data : officialEvents
}

export async function getSampleEvents(): Promise<CampusEvent[]> {
  return sampleEvents
}

export async function getEventById(id: string): Promise<CampusEvent | undefined> {
  const result = await getLiveEvents()
  const liveEvent = result.data.find((event) => event.id === id)
  if (liveEvent) return liveEvent
  return sampleEvents.find((event) => event.id === id)
}
