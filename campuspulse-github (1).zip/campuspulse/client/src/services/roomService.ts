// Obsidian Pulse reminder: Room availability is intentionally isolated from UI concerns.
import { locations, resources, type CampusLocation, type Resource } from '@/data/mockData'

export async function getResources(): Promise<Resource[]> {
  return Promise.resolve(resources)
}

export async function getLocations(): Promise<CampusLocation[]> {
  return Promise.resolve(locations)
}
