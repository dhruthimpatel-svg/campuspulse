import { supabase } from '@/lib/supabase'
import type { Announcement, CampusEvent, Club, CampusLocation, Resource, EventCategory, Priority, ResourceStatus } from '@/data/mockData'

export type LiveDataState = 'live' | 'empty' | 'unconfigured' | 'error'
export type LiveResult<T> = { data: T; state: LiveDataState; error?: string }

const configured = Boolean(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY)

function unavailable(message = 'Information unavailable in the current official sync.') {
  return message
}

function asCategory(value: unknown): EventCategory {
  const categories: EventCategory[] = ['Technical', 'Cultural', 'Sports', 'Workshop', 'Competition', 'Club Event']
  return categories.includes(value as EventCategory) ? value as EventCategory : 'Technical'
}

function asPriority(value: unknown): Priority {
  const priorities: Priority[] = ['Important', 'General', 'Event', 'Academic']
  return priorities.includes(value as Priority) ? value as Priority : 'General'
}

function asResourceStatus(value: unknown): ResourceStatus {
  const statuses: ResourceStatus[] = ['Available', 'Busy', 'Maintenance', 'Unavailable']
  return statuses.includes(value as ResourceStatus) ? value as ResourceStatus : 'Unavailable'
}

function formatDate(value: unknown) {
  if (!value) return 'Date unavailable'
  const parsed = new Date(String(value))
  return Number.isNaN(parsed.getTime()) ? 'Date unavailable' : parsed.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' })
}

function mapEvent(row: Record<string, unknown>): CampusEvent {
  const dateISO = typeof row.date_iso === 'string' ? row.date_iso : typeof row.dateISO === 'string' ? row.dateISO : undefined
  return {
    id: String(row.id),
    title: String(row.title ?? 'Untitled event'),
    category: asCategory(row.category),
    dateLabel: formatDate(dateISO),
    dateISO,
    time: String(row.time ?? 'Time unavailable'),
    location: String(row.location ?? 'Venue unavailable'),
    organizer: String(row.organizer ?? 'BNMIT'),
    seats: typeof row.seats === 'number' ? row.seats : undefined,
    capacity: typeof row.capacity === 'number' ? row.capacity : undefined,
    description: String(row.description ?? unavailable()),
    image: String(row.image_url ?? row.image ?? '/manus-storage/campuspulse-style-reference_078db393.png'),
    accent: '#C8F169',
    tags: Array.isArray(row.tags) ? row.tags.map(String) : [],
    status: row.status === 'demo' ? 'demo' : 'official',
    registrationLink: typeof row.registration_link === 'string' ? row.registration_link : undefined,
  }
}

function mapClub(row: Record<string, unknown>): Club {
  const name = String(row.name ?? 'BNMIT club')
  return {
    id: String(row.id),
    name,
    category: String(row.category ?? 'BNMIT student club'),
    description: String(row.description ?? unavailable()),
    facultyCoordinator: String(row.faculty_coordinator ?? unavailable('Faculty coordinator unavailable.')),
    studentCoordinator: String(row.student_coordinator ?? unavailable('Student coordinator unavailable.')),
    officialUrl: String(row.official_url ?? 'https://www.bnmit.org/clubs/'),
    socialUrl: typeof row.social_url === 'string' ? row.social_url : undefined,
    initials: name.split(/\s+/).map((part) => part[0]).join('').slice(0, 3).toUpperCase(),
    accent: '#C8F169',
    members: typeof row.members === 'number' ? row.members : undefined,
    upcomingEvent: typeof row.upcoming_event === 'string' ? row.upcoming_event : undefined,
  }
}

function mapAnnouncement(row: Record<string, unknown>): Announcement {
  return {
    id: String(row.id),
    title: String(row.title ?? 'BNMIT announcement'),
    description: String(row.description ?? unavailable()),
    date: formatDate(row.published_at ?? row.date),
    priority: asPriority(row.priority),
    unread: Boolean(row.unread ?? true),
    officialUrl: typeof row.official_url === 'string' ? row.official_url : undefined,
  }
}

function mapResource(row: Record<string, unknown>): Resource {
  return {
    id: String(row.id),
    name: String(row.name ?? 'BNMIT resource'),
    type: String(row.type ?? 'Student resource'),
    status: asResourceStatus(row.status),
    detail: String(row.detail ?? unavailable()),
    officialUrl: typeof row.official_url === 'string' ? row.official_url : undefined,
    capacity: typeof row.capacity === 'string' ? row.capacity : undefined,
  }
}

function mapLocation(row: Record<string, unknown>): CampusLocation {
  return {
    id: String(row.id),
    name: String(row.name ?? 'BNMIT'),
    officialUrl: String(row.official_url ?? 'https://www.bnmit.org/'),
    description: String(row.description ?? 'BNMIT campus location'),
    x: typeof row.x === 'number' ? row.x : undefined,
    y: typeof row.y === 'number' ? row.y : undefined,
    status: asResourceStatus(row.status),
    hours: typeof row.hours === 'string' ? row.hours : undefined,
    availability: typeof row.availability === 'string' ? row.availability : undefined,
    activity: typeof row.activity === 'string' ? row.activity : undefined,
  }
}

async function query<T>(table: string, mapper: (row: Record<string, unknown>) => T, options?: { order?: string; ascending?: boolean }): Promise<LiveResult<T[]>> {
  if (!configured) return { data: [], state: 'unconfigured', error: 'Supabase environment variables are not configured.' }
  let request = supabase.from(table).select('*')
  if (options?.order) request = request.order(options.order, { ascending: options.ascending ?? false })
  const { data, error } = await request
  if (error) return { data: [], state: 'error', error: error.message }
  const rows = (data ?? []).map((row) => mapper(row as Record<string, unknown>))
  return { data: rows, state: rows.length ? 'live' : 'empty' }
}

export async function getLiveEvents(): Promise<LiveResult<CampusEvent[]>> {
  const result = await query('events', mapEvent, { order: 'date_iso', ascending: true })
  if (!result.data.length) return result
  const now = Date.now()
  const upcoming = result.data.filter((event) => !event.dateISO || new Date(event.dateISO).getTime() >= now)
  return { ...result, data: upcoming, state: upcoming.length ? 'live' : 'empty' }
}

export const getLiveClubs = () => query('clubs', mapClub, { order: 'name', ascending: true })
export const getLiveAnnouncements = () => query('announcements', mapAnnouncement, { order: 'published_at', ascending: false })
export const getLiveResources = () => query('resources', mapResource, { order: 'name', ascending: true })
export const getLiveLocations = () => query('campus_locations', mapLocation, { order: 'name', ascending: true })

export async function createEvent(payload: Partial<CampusEvent> & { isPublished?: boolean }) {
  return supabase.from('events').insert({ title: payload.title, category: payload.category, date_iso: payload.dateISO, time: payload.time, location: payload.location, organizer: payload.organizer, description: payload.description, capacity: payload.capacity, seats: payload.seats, image_url: payload.image, tags: payload.tags ?? [], status: 'official', is_published: payload.isPublished ?? false, registration_link: payload.registrationLink }).select().single()
}

export async function updateEvent(id: string, payload: Partial<CampusEvent>) {
  return supabase.from('events').update({ title: payload.title, category: payload.category, date_iso: payload.dateISO, time: payload.time, location: payload.location, organizer: payload.organizer, description: payload.description, capacity: payload.capacity, seats: payload.seats, image_url: payload.image, tags: payload.tags, registration_link: payload.registrationLink, updated_at: new Date().toISOString() }).eq('id', id).select().single()
}

export async function deleteEvent(id: string) {
  return supabase.from('events').delete().eq('id', id)
}

export async function createAnnouncement(payload: Pick<Announcement, 'title' | 'description' | 'priority' | 'officialUrl'> & { isPublished?: boolean }) {
  return supabase.from('announcements').insert({ title: payload.title, description: payload.description, priority: payload.priority, is_published: payload.isPublished ?? false, official_url: payload.officialUrl }).select().single()
}

export async function updateClub(id: string, payload: Partial<Club>) {
  return supabase.from('clubs').update({ name: payload.name, category: payload.category, description: payload.description, faculty_coordinator: payload.facultyCoordinator, student_coordinator: payload.studentCoordinator, official_url: payload.officialUrl, social_url: payload.socialUrl, updated_at: new Date().toISOString() }).eq('id', id).select().single()
}
