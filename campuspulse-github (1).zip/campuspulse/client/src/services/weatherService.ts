// Obsidian Pulse reminder: Keep this response shape stable for a future weather provider.
export interface WeatherSnapshot {
  temperature: number
  condition: string
  humidity: number
  windSpeed: number
  location: string
  updatedAt: string
}

export async function getWeather(): Promise<WeatherSnapshot> {
  return Promise.resolve({
    temperature: 28,
    condition: 'Partly cloudy',
    humidity: 64,
    windSpeed: 12,
    location: 'Campus North',
    updatedAt: 'Updated 8 min ago',
  })
}
