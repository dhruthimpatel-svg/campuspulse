# CampusPulse Design Brainstorm

## Approach 1 — Obsidian Pulse
Very dark, editorial product design with liquid-glass surfaces, raw campus video, and a restrained electric-lime signal color. The experience feels like an intelligent operating layer over student life: calm, precise, and kinetic without becoming cyberpunk.

**Probability:** 0.07

## Approach 2 — Daylight Commons
A high-key, architectural campus interface with warm paper white, graphite type, translucent panels, and cobalt wayfinding accents. The product feels open, civic, and optimistic, like a beautifully designed campus guide.

**Probability:** 0.04

## Approach 3 — Signal Atlas
A monochrome cartographic system inspired by transit maps and technical field notes, with orange-red wayfinding marks, hard-edged modules, and dense information choreography. The product feels exploratory, resourceful, and urban.

**Probability:** 0.02

# Chosen Approach — Obsidian Pulse

## Design Movement
Contemporary digital brutalism softened by liquid-glass product UI and editorial motion design. The visual language combines near-black negative space, reflective surfaces, sharp information hierarchy, and a single signal color that behaves like a live data pulse.

## Core Principles
1. **Signal over decoration.** Every accent, glow, motion cue, and border communicates status, direction, or interaction.
2. **Editorial asymmetry.** Use off-center compositions, split rails, tall cards, and staggered content rather than generic centered SaaS grids.
3. **Tactile translucency.** Surfaces should feel layered and physical through blur, inset highlights, restrained radii, and quiet depth.
4. **Motion with restraint.** Animate entrances, hover responses, and meaningful state changes; never make the interface compete with the content.

## Color Philosophy
Near-black is the canvas because campus life is noisy; dark space lets the most important signals read instantly. White and cool grays establish product clarity, while **Pulse Lime** is reserved for active states, live availability, selected map locations, and small moments of energy. There are no decorative gradients and no purple/indigo SaaS cues. The palette should feel like a premium device interface with one living indicator.

## Layout Paradigm
Use a **split-orbit layout**: a broad editorial content field paired with narrow context rails. The hero is a full-bleed video stage with controls and copy anchored low; product pages use a persistent left identity rail on desktop, an uneven content column, and secondary cards that orbit the main task. On mobile, the rail collapses into a compact command header and the visual hierarchy remains asymmetric through varying card heights and horizontal overflow strips.

## Signature Elements
- A thin **pulse line** that appears as a signal trace in section headers, charts, and selected states.
- **Glass capsules** with a reflective top edge and tiny monospace metadata labels.
- Small lime **activity pips** that pulse only when representing live or available status.

## Interaction Philosophy
Interactions should feel like operating a calm instrument panel. Hover states reveal intent through a lift, border clarity, or a short signal sweep; clicks confirm with a quick compression and a state change. Filters should update immediately and visibly. Dialogs and the assistant open from their trigger origin, while keyboard focus stays obvious and never disappears into the glass.

## Animation
Use 180–280ms ease-out transitions for buttons, cards, filters, and menus. Entrance reveals use opacity plus translateY(12px) or translateX(-12px), staggered 40–70ms across groups. Hero heading characters enter from the left with the specified 30ms stagger and 500ms duration; the raw background video remains dominant and never receives an overlay. The assistant uses a 220ms scale/opacity reveal from the floating button. Charts draw in once on entry. The pulse pips use a restrained 2.8s opacity/scale loop only for live states. All non-essential animation is disabled or simplified under prefers-reduced-motion.

## Typography System
Use **Inter** as the required global UI family, with weight contrast doing the editorial work: 300 for hero and large metric numerals, 400 for body, 500–600 for controls and labels. Use `ui-monospace` for compact metadata, times, counts, and system-like annotations. Headlines use tight tracking around -0.04em and generous line-height; supporting copy stays at 15–18px with relaxed line-height. Avoid all-caps except for tiny metadata labels.

## Brand Essence
CampusPulse is the intelligent layer for students who want the campus to make sense at a glance—events, people, places, and availability connected in one calm interface.

**Personality:** incisive, energetic, composed.

## Brand Voice
Headlines are short, confident, and observant. CTAs use active verbs and imply movement rather than administration. Microcopy is human but concise, with occasional system-like precision.

Example lines:
- “Everything happening here, in one pulse.”
- “Find your next signal.”

## Wordmark & Logo
Use a custom symbol rather than default text styling: a compact circular pulse mark formed from two offset arcs and a single lime center pip, suggesting a campus node network and a heartbeat. Pair it with the text wordmark in Inter Semibold with a deliberate tight tracking treatment; the icon remains legible as the favicon and mobile mark.

## Signature Brand Color
**Pulse Lime — `#C8F169`**. It is warm enough to feel human, bright enough to read against obsidian, and distinctive when used sparingly as an active signal rather than a general highlight.

## Implementation Reminder
The user requirements specify a raw full-screen hero video, black/near-black surfaces, Inter, functional multi-page navigation, API-ready service boundaries, mock data only, and no backend. The implementation will honor those constraints while applying the Obsidian Pulse system consistently.

## Style Decisions
- Preserve raw hero video without a dark, gradient, or translucent overlay; ensure contrast through placement, type weight, glass surfaces, and restrained text shadows rather than dimming the video.
- Reserve Pulse Lime for live/active/available states and occasional data emphasis.
- Keep desktop composition asymmetric and rail-led; collapse gracefully to stacked mobile flows.
- Keep the first delivery frontend-only with mock service modules and functional client interactions.

- Internal desktop pages retain a visible identity/context rail as a structural requirement, not just a utility header.
- Non-status categories stay neutral by default; Pulse Lime is the only high-energy accent for live, active, available, selected, or key data states.
- Event and workshop actions use movement language such as “Join the signal” and “Join session” in place of generic registration wording.
- Event imagery uses a consistent dark editorial documentary treatment rather than failed or mixed placeholder media.
